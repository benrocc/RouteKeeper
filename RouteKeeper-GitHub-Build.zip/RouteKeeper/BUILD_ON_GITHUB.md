# Build RouteKeeper APK with GitHub Actions

This project includes `.github/workflows/build-apk.yml`.

Once the project is uploaded to a GitHub repository, GitHub Actions will build the Android APK automatically on pushes to `main` or `master`. It can also be started manually from **Actions > Build RouteKeeper APK > Run workflow**.

When the run finishes, open the completed workflow run and download the artifact named **RouteKeeper-APK**. Inside it is **RouteKeeper.apk**, ready to install on Android.
