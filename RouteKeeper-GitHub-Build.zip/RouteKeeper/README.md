# RouteKeeper
Android app for creating and saving preferred driving routes, then launching them in Google Maps.

## How to use
- Tap **My location** to set the start, or tap the map to set it manually.
- Tap map points along roads you want to force the route through.
- Tap **Set destination** to convert the last point into the destination, or long-press the map to set the destination directly.
- Save the route by name.
- Tap **Navigate in Google Maps** to hand the route to the installed Google Maps app.

## Build
Open this folder in Android Studio. Let Gradle sync, then Build > Build APK(s).
No Google Maps API key is required. The in-app map uses OpenStreetMap and the route preview uses the public OSRM routing service.
